#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File
#include "VarMean.h"
#include "CoreCtrl.h"
float dvtd_buffer[68][N];
float VarMeanOut[N]={0};
float rtb_Vq[N]={0};
B_varMean_T varMean_B;
#pragma CODE_SECTION(varMean_step, "ramfuncs")
void varMean_step(void)
{
	float rtb_sinwt2pi3_b;
	float rtb_UnitDelay;
	float rtb_Sum1_p;
	float rtb_Kp6,rtb_varr,rtb_vari;
	float *tmp,*tnp,*tkp,*tbp,*thp,*vmo;
	int i,n,m,k,y;
	tmp = &varMean_B.Integ4[0];
	tnp = &varMean_B.Integ4_DSTATE[0];
	tkp = &rtb_Vq[0];
	for(i=N;i;i--){
		/* DiscreteIntegrator: '<S6>/Integ4' */
		if (varMean_B.Integ4_SYSTEM_ENABLE != 0U) {      //��ʼ�ж�
			varMean_B.Integ4[i] = varMean_B.Integ4_DSTATE[i];
		} else {
			*tmp++ = Integ4_gainval_d * *tkp++ + *tnp++;
//  		 varMean_B.Integ4[i] = varMean_B.Integ4_gainval_d * rtb_Vq[i] +  varMean_B.Integ4_DSTATE[i];   //��ɢ��������
		}
	}
	rtb_UnitDelay = varMean_B.UnitDelay_DSTATE;      //����������浱ǰֵ
	/* Saturate: '<S6>/To avoid division by zero' incorporates:*/
	if (varMean_B.UnitDelay_DSTATE >= Toavoiddivisionbyzero_UpperSa_o)//�ж� ���������rtb_Kp6 ������1e6������1e-6֮��
		{ rtb_Kp6 = Toavoiddivisionbyzero_UpperSa_o;
	} else if (varMean_B.UnitDelay_DSTATE <= Toavoiddivisionbyzero_LowerSa_h) {
		rtb_Kp6 = Toavoiddivisionbyzero_LowerSa_h;
	} else {
		rtb_Kp6 = varMean_B.UnitDelay_DSTATE;
	}
	rtb_Sum1_p = (Step) / rtb_Kp6;                    //  rtb_Kp6:fcn����������u[1]
	rtb_sinwt2pi3_b = (int)(rtb_Sum1_p+1);               // rtb_Sum1_p:ceil��������/
	varMean_B.Delay = Gain_Gain_e * rtb_sinwt2pi3_b;  // Ts:Gain*ceil
	/* S-Function block: <S19>/S-Function  */
	tmp = &varMean_B.Integ4[0];
	tnp = &dvtd_buffer[varMean_B.indEnd][0];
	for(n=N;n;n--){//144
		*tnp++ = *tmp++;
//		dvtd_buffer[n][varMean_B.indEnd] = varMean_B.Integ4[n];//Sfcn��In����
	}
    int indDelayed;
    /* Calculate delayed index */
    int discreteDelay =(int)((varMean_B.Delay*Step) + 0.5);//GAIN������varMean_B.Delay��S-fcn������������
    if (discreteDelay > (bufSz - 1)){        // ��ɢ�����ӳٿ�����Ԥ��ֵ֮��
    	discreteDelay = (bufSz - 1);
    }
    indDelayed = varMean_B.indEnd - ((discreteDelay > 0) ? discreteDelay : 0); //����ƫ��ֵ
	if (indDelayed < 0) {
		if (varMean_B.indBeg == 0)
			indDelayed = 0;
		else
			indDelayed += bufSz;
	}
	tmp = &varMean_B.SFunction[0];
	tnp = &dvtd_buffer[indDelayed][0];
	for(m=N;m;m--){//144
		*tmp++ = *tnp++;
//		 varMean_B.SFunction[m] = dvtd_buffer[m][indDelayed];
	}
	rtb_Kp6 = rtb_Sum1_p - rtb_sinwt2pi3_b;
	rtb_vari = rtb_Kp6*Gain1_Gain_o;
	rtb_varr = rtb_Kp6 / rtb_Sum1_p;
	tnp = &rtb_Vq[0];
	tmp = &varMean_B.UnitDelay_DSTATE_n[0];
	tkp = &varMean_B.Integ4[0];
	tbp = &varMean_B.SFunction[0];
	thp = &varMean_B.Integ4_DSTATE[0];
	vmo = &VarMeanOut[0];
	for(k=N;k;k--){//1024/* Sum: '<S18>/Sum5' */
		*vmo++ = ((*tnp - *tmp++) * rtb_vari+ *tnp) * (rtb_varr) + (*tkp - *tbp++) * rtb_UnitDelay;
		/* Update for DiscreteIntegrator: '<S6>/Integ4' */
		*thp++ = Integ4_gainval_d * *tnp++ + *tkp++;
	}
//  for(k=0;k<N;k++){
//      /* Sum: '<S18>/Sum5' */
//      rtb_Kp6 = rtb_Sum1_p - rtb_sinwt2pi3_b;
//      rtb_Divide[k] = ((rtb_Vq[k] - varMean_B.UnitDelay_DSTATE_n[k]) * rtb_Kp6 *
//    		  	  	  varMean_B.Gain1_Gain_o + rtb_Vq[k]) * (rtb_Kp6 / rtb_Sum1_p) +
//    				  (varMean_B.Integ4[k] - varMean_B.SFunction[k]) * rtb_UnitDelay;
//      MeanOutTest[k] = rtb_Divide[k];
//  /* Update for DiscreteIntegrator: '<S6>/Integ4' */
//  varMean_B.Integ4_SYSTEM_ENABLE = 0U;                                //������ʼ�ж�����
//  varMean_B.Integ4_DSTATE[k] = varMean_B.Integ4_gainval_d * rtb_Vq[k] + varMean_B.Integ4[k];
//  }
	varMean_B.Integ4_SYSTEM_ENABLE = 0U;       /* S-Function block: <S19>/S-Function  */                                                               //����sfcn ��ֵ
	int indBeg = varMean_B.indBeg;
	int indEnd = varMean_B.indEnd;
	int BbufSz = bufSz;
	indEnd = indEnd < BbufSz-1 ? indEnd+1 : 0;
	if (indEnd == indBeg) {
		indBeg = indBeg < BbufSz-1 ? indBeg+1 : 0;
	}
	varMean_B.indBeg = indBeg;
	varMean_B.indEnd = indEnd;
	tmp = &varMean_B.UnitDelay_DSTATE_n[0];
	tnp = &rtb_Vq[0];
	for(y=N;y;y--){            /* <S18>/Unit Delay'����correctionģ�� */
		*tmp++ = *tnp++;
	//	  varMean_B.UnitDelay_DSTATE_n[y] = rtb_Vq[y];
	}
  }
void varMean_initialize(void)
{
	float *p=&dvtd_buffer[0][0];
	int i;
	for(i=0;i<sizeof(dvtd_buffer)/2;i++){
		*p++ = 0;
	}

	int *q=&varMean_B.indBeg;
	for(i=0;i<sizeof(B_varMean_T);i++){
		*q++ = 0;
	}
	varMean_B.indEnd = 1;
	varMean_B.Integ4_SYSTEM_ENABLE = 1U;
}
