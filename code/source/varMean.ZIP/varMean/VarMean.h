/* varMean.h */
#include <math.h>
#include <stddef.h>
#include "CoreCtrl.h"
#ifndef RTW_HEADER_varMean_h_
#define RTW_HEADER_varMean_h_
#ifndef varMean_COMMON_INCLUDES_
# define varMean_COMMON_INCLUDES_
#endif                                 /* varMean_COMMON_INCLUDES_ */
#define N 5
#define Step                             (VarMeanStep)  // 8K,9.6K(2*PWMFREQUENCY/6);12.8k,16K(PWMFREQUENCY/6)
#define Ts                               (1/Step)    //��������
#define Integ4_gainval_d                 (0.5*Ts)
#define Gain1_Gain_o                     (0.5)
#define Toavoiddivisionbyzero_UpperSa_o  (52.5)        //Ƶ���޶�����
#define Toavoiddivisionbyzero_LowerSa_h  (47.5)        //Ƶ���޶�����
#define Gain_Gain_e                      (Ts)
#define bufSz                            (68)          //����������dvtd_buffer[68][N]//  68=VarMeanStep/(50-fv)����ȡ��   fv=Ƶ�ʲ�����Χ
extern float rtb_Vq[N];
extern float VarMeanOut[N];
extern float dvtd_buffer[1 * 68][N];
typedef struct {
////////////////////////////////////////////////////////////////DW_varMean_T
	int   indBeg;                       /* Expression: 0    '<S19>/S-Function ' */
	int   indEnd;                       /* Expression: 1    '<S19>/S-Function ' */
    float Integ4_DSTATE[N];                /* Expression: 0    '<S6>/Integ4' */
    float UnitDelay_DSTATE_n[N];           /* Expression: 0    '<S18>/Unit Delay' */
    float Integ4_SYSTEM_ENABLE;         /* Expression: 1U   '<S6>/Integ4' */
//////////////////////////////////////////////////////////////////P_varMean_T_
//	float Gain1_Gain_o;                    // Expression: 0.5        Referenced by: '<S18>/Gain1'
//	float Integ4_gainval_d;                // Expression: 0.5*Ts     Referenced by: '<S6>/Integ4'
//	float Toavoiddivisionbyzero_UpperSa_o; // Expression: 1e6        Referenced by: '<S6>/To avoid division by zero'
//	float Toavoiddivisionbyzero_LowerSa_h; // Expression: 1e-6       Referenced by: '<S6>/To avoid division by zero'
//	float Gain_Gain_e;                     // Expression: Ts         Referenced by: '<S6>/Gain'
/////////////////////////////////////////////////////////////B_varMean_T
    float Integ4[N];                       /* '<S6>/Integ4' */
    float Delay;                        /* '<S6>/Gain' */
    float SFunction[N];                    /* '<S19>/S-Function ' */
////////////////////////////////////////////////////////////////DW_varMean_T
//  void *uBuffers;                     /* '<S19>/S-Function ' */
    float UnitDelay_DSTATE;             /* Expression: fs   '<S1>/Unit Delay' */
//	void *uBuffers;                     /* '<S19>/S-Function ' */
//	int   bufSz;                        /* Expression: 128  '<S19>/S-Function ' */
//	int   maxDiscrDelay;                /* Expression: 127  '<S19>/S-Function  maxDiscrDelay = bufSz-1   */
} B_varMean_T;
//#define varMean_B_data {0,0,0,0,0,0,0,1,128,127,1U,0.5,0.5*Ts,1e6,1e-6,Ts,0,0,0,0,0,0,0,0,0}
extern B_varMean_T varMean_B;
extern void varMean_initialize(void);
extern void varMean_step(void);
#endif    /* RTW_HEADER_varMean_h_ */
/*
varMean_B.Gain_Gain_e = Ts;
varMean_B.Integ4_DSTATE[N] = 0;
varMean_B.UnitDelay_DSTATE_n[N] = 0;
varMean_B.Delay = 0;
varMean_B.Gain1_Gain_o = 0.5;
varMean_B.Integ4[N] = 0;
varMean_B.Integ4_DSTATE[N] = 0;
varMean_B.Integ4_SYSTEM_ENABLE = 1U;
varMean_B.Integ4_gainval_d = 0.5*Ts;
varMean_B.SFunction[N] = 0;
varMean_B.Toavoiddivisionbyzero_LowerSa_h = 1e-6;
varMean_B.Toavoiddivisionbyzero_UpperSa_o = 1e6;
varMean_B.bufSz = 128;
varMean_B.maxDiscrDelay = 127;
varMean_B.indEnd = 1;
varMean_B.indBeg = 0;
*/
